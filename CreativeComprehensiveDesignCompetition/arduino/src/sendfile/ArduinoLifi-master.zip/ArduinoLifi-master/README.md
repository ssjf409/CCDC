# ArduinoLifi

This is a project for our Wireless Applications class.

This project allows for sending files using LiFi and two Arduinos

Example Video:
https://www.youtube.com/watch?v=HPLPHPC3PuU

